# Data Transformer
Simple project that reads a file, transforms it, and writes the output.