
import os

def read_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.readlines()

def transform_data(lines):
    return [line.strip().upper() for line in lines if line.strip()]

def save_file(lines, output_path):
    with open(output_path, 'w', encoding='utf-8') as f:
        f.writelines([line + '\n' for line in lines])

def main():
    input_path = 'input.txt'
    output_path = 'output.txt'

    lines = read_file(input_path)
    transformed = transform_data(lines)
    save_file(transformed, output_path)
